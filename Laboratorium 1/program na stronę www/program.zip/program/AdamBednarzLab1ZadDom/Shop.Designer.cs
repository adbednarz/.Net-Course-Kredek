﻿
namespace AdamBednarzLab1ZadDom
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1BuyPremiun = new System.Windows.Forms.Button();
            this.button2BuyPremium = new System.Windows.Forms.Button();
            this.button3Buy = new System.Windows.Forms.Button();
            this.button4BuyPremium = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBoxOrganic = new System.Windows.Forms.PictureBox();
            this.pictureBoxSprayer = new System.Windows.Forms.PictureBox();
            this.pictureBoxMedicaments = new System.Windows.Forms.PictureBox();
            this.pictureBoxVitamins = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.button2Buy = new System.Windows.Forms.Button();
            this.button1Buy = new System.Windows.Forms.Button();
            this.button4Buy = new System.Windows.Forms.Button();
            this.button4BuyMedium = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrganic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSprayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedicaments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVitamins)).BeginInit();
            this.SuspendLayout();
            // 
            // button1BuyPremiun
            // 
            this.button1BuyPremiun.BackColor = System.Drawing.Color.BurlyWood;
            this.button1BuyPremiun.Location = new System.Drawing.Point(383, 91);
            this.button1BuyPremiun.Name = "button1BuyPremiun";
            this.button1BuyPremiun.Size = new System.Drawing.Size(143, 44);
            this.button1BuyPremiun.TabIndex = 0;
            this.button1BuyPremiun.Text = "KUP PREMIUM";
            this.button1BuyPremiun.UseVisualStyleBackColor = false;
            this.button1BuyPremiun.Click += new System.EventHandler(this.Button1BuyPremium_Click);
            // 
            // button2BuyPremium
            // 
            this.button2BuyPremium.BackColor = System.Drawing.Color.BurlyWood;
            this.button2BuyPremium.Location = new System.Drawing.Point(383, 280);
            this.button2BuyPremium.Name = "button2BuyPremium";
            this.button2BuyPremium.Size = new System.Drawing.Size(143, 44);
            this.button2BuyPremium.TabIndex = 1;
            this.button2BuyPremium.Text = "KUP PREMIUM";
            this.button2BuyPremium.UseVisualStyleBackColor = false;
            this.button2BuyPremium.Click += new System.EventHandler(this.Button2BuyPremium_Click);
            // 
            // button3Buy
            // 
            this.button3Buy.BackColor = System.Drawing.Color.BurlyWood;
            this.button3Buy.Location = new System.Drawing.Point(383, 471);
            this.button3Buy.Name = "button3Buy";
            this.button3Buy.Size = new System.Drawing.Size(143, 69);
            this.button3Buy.TabIndex = 2;
            this.button3Buy.Text = "KUP";
            this.button3Buy.UseVisualStyleBackColor = false;
            this.button3Buy.Click += new System.EventHandler(this.Button3Buy_Click);
            // 
            // button4BuyPremium
            // 
            this.button4BuyPremium.BackColor = System.Drawing.Color.BurlyWood;
            this.button4BuyPremium.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4BuyPremium.Location = new System.Drawing.Point(383, 692);
            this.button4BuyPremium.Name = "button4BuyPremium";
            this.button4BuyPremium.Size = new System.Drawing.Size(143, 23);
            this.button4BuyPremium.TabIndex = 3;
            this.button4BuyPremium.Text = "KUP PREMIUM";
            this.button4BuyPremium.UseVisualStyleBackColor = false;
            this.button4BuyPremium.Click += new System.EventHandler(this.Button4BuyPremium_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(249, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Koszt: 5000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(243, 259);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Koszt: 2000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(249, 525);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Koszt: 500";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(250, 671);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Koszt: 400";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(266, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Nawóz";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(249, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Opryski";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(250, 471);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Lekarstwa";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(250, 599);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 15);
            this.label8.TabIndex = 15;
            this.label8.Text = "Witaminy";
            // 
            // pictureBoxOrganic
            // 
            this.pictureBoxOrganic.Image = global::AdamBednarzLab1ZadDom.Properties.Resources.organic;
            this.pictureBoxOrganic.Location = new System.Drawing.Point(65, 25);
            this.pictureBoxOrganic.Name = "pictureBoxOrganic";
            this.pictureBoxOrganic.Size = new System.Drawing.Size(100, 81);
            this.pictureBoxOrganic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxOrganic.TabIndex = 16;
            this.pictureBoxOrganic.TabStop = false;
            // 
            // pictureBoxSprayer
            // 
            this.pictureBoxSprayer.Image = global::AdamBednarzLab1ZadDom.Properties.Resources.sprayer;
            this.pictureBoxSprayer.Location = new System.Drawing.Point(65, 223);
            this.pictureBoxSprayer.Name = "pictureBoxSprayer";
            this.pictureBoxSprayer.Size = new System.Drawing.Size(100, 72);
            this.pictureBoxSprayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSprayer.TabIndex = 17;
            this.pictureBoxSprayer.TabStop = false;
            // 
            // pictureBoxMedicaments
            // 
            this.pictureBoxMedicaments.Image = global::AdamBednarzLab1ZadDom.Properties.Resources.medicaments;
            this.pictureBoxMedicaments.Location = new System.Drawing.Point(65, 420);
            this.pictureBoxMedicaments.Name = "pictureBoxMedicaments";
            this.pictureBoxMedicaments.Size = new System.Drawing.Size(100, 83);
            this.pictureBoxMedicaments.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxMedicaments.TabIndex = 18;
            this.pictureBoxMedicaments.TabStop = false;
            // 
            // pictureBoxVitamins
            // 
            this.pictureBoxVitamins.Image = global::AdamBednarzLab1ZadDom.Properties.Resources.vitamins;
            this.pictureBoxVitamins.Location = new System.Drawing.Point(65, 599);
            this.pictureBoxVitamins.Name = "pictureBoxVitamins";
            this.pictureBoxVitamins.Size = new System.Drawing.Size(100, 67);
            this.pictureBoxVitamins.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxVitamins.TabIndex = 19;
            this.pictureBoxVitamins.TabStop = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Location = new System.Drawing.Point(65, 119);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(100, 83);
            this.richTextBox1.TabIndex = 20;
            this.richTextBox1.Text = "Zwiększa wydajność plonów przez pewien czas.";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.richTextBox2.Enabled = false;
            this.richTextBox2.Location = new System.Drawing.Point(65, 301);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(100, 83);
            this.richTextBox2.TabIndex = 21;
            this.richTextBox2.Text = "Zwiększa wydajność plonów przez pewien czas.";
            // 
            // richTextBox3
            // 
            this.richTextBox3.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.richTextBox3.Enabled = false;
            this.richTextBox3.Location = new System.Drawing.Point(65, 509);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(100, 61);
            this.richTextBox3.TabIndex = 22;
            this.richTextBox3.Text = "Zwięrzęta rzadziej umierają przez pewnien czas.";
            // 
            // richTextBox4
            // 
            this.richTextBox4.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.richTextBox4.Enabled = false;
            this.richTextBox4.Location = new System.Drawing.Point(65, 678);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.Size = new System.Drawing.Size(100, 58);
            this.richTextBox4.TabIndex = 23;
            this.richTextBox4.Text = "Zwierzęta szybciej produkują zasoby. przez pewien czas.";
            // 
            // button2Buy
            // 
            this.button2Buy.BackColor = System.Drawing.Color.BurlyWood;
            this.button2Buy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2Buy.Location = new System.Drawing.Point(383, 234);
            this.button2Buy.Name = "button2Buy";
            this.button2Buy.Size = new System.Drawing.Size(143, 40);
            this.button2Buy.TabIndex = 24;
            this.button2Buy.Text = "KUP";
            this.button2Buy.UseVisualStyleBackColor = false;
            this.button2Buy.Click += new System.EventHandler(this.Button2Buy_Click);
            // 
            // button1Buy
            // 
            this.button1Buy.BackColor = System.Drawing.Color.BurlyWood;
            this.button1Buy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1Buy.Location = new System.Drawing.Point(383, 45);
            this.button1Buy.Name = "button1Buy";
            this.button1Buy.Size = new System.Drawing.Size(143, 40);
            this.button1Buy.TabIndex = 25;
            this.button1Buy.Text = "KUP";
            this.button1Buy.UseVisualStyleBackColor = false;
            this.button1Buy.Click += new System.EventHandler(this.Button1Buy_Click);
            // 
            // button4Buy
            // 
            this.button4Buy.BackColor = System.Drawing.Color.BurlyWood;
            this.button4Buy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4Buy.Location = new System.Drawing.Point(383, 634);
            this.button4Buy.Name = "button4Buy";
            this.button4Buy.Size = new System.Drawing.Size(143, 23);
            this.button4Buy.TabIndex = 26;
            this.button4Buy.Text = "KUP";
            this.button4Buy.UseVisualStyleBackColor = false;
            this.button4Buy.Click += new System.EventHandler(this.Button4Buy_Click);
            // 
            // button4BuyMedium
            // 
            this.button4BuyMedium.BackColor = System.Drawing.Color.BurlyWood;
            this.button4BuyMedium.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4BuyMedium.Location = new System.Drawing.Point(383, 663);
            this.button4BuyMedium.Name = "button4BuyMedium";
            this.button4BuyMedium.Size = new System.Drawing.Size(143, 23);
            this.button4BuyMedium.TabIndex = 28;
            this.button4BuyMedium.Text = "KUP MEDIUM";
            this.button4BuyMedium.UseVisualStyleBackColor = false;
            this.button4BuyMedium.Click += new System.EventHandler(this.Button4BuyMedium_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(250, 700);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 15);
            this.label9.TabIndex = 29;
            this.label9.Text = "Koszt: 500";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(250, 642);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 15);
            this.label10.TabIndex = 30;
            this.label10.Text = "Koszt: 300";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(243, 309);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 15);
            this.label11.TabIndex = 31;
            this.label11.Text = "Koszt: 5000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(250, 120);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 15);
            this.label12.TabIndex = 32;
            this.label12.Text = "Koszt: 8000";
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(582, 767);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button4BuyMedium);
            this.Controls.Add(this.button4Buy);
            this.Controls.Add(this.button1Buy);
            this.Controls.Add(this.button2Buy);
            this.Controls.Add(this.richTextBox4);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.pictureBoxVitamins);
            this.Controls.Add(this.pictureBoxMedicaments);
            this.Controls.Add(this.pictureBoxSprayer);
            this.Controls.Add(this.pictureBoxOrganic);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4BuyPremium);
            this.Controls.Add(this.button3Buy);
            this.Controls.Add(this.button2BuyPremium);
            this.Controls.Add(this.button1BuyPremiun);
            this.Name = "Shop";
            this.Text = "Shop";
            this.Load += new System.EventHandler(this.Shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrganic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSprayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedicaments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVitamins)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1BuyPremiun;
        private System.Windows.Forms.Button button2BuyPremium;
        private System.Windows.Forms.Button button3Buy;
        private System.Windows.Forms.Button button4BuyPremium;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBoxOrganic;
        private System.Windows.Forms.PictureBox pictureBoxSprayer;
        private System.Windows.Forms.PictureBox pictureBoxMedicaments;
        private System.Windows.Forms.PictureBox pictureBoxVitamins;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Button button2Buy;
        private System.Windows.Forms.Button button1Buy;
        private System.Windows.Forms.Button button4Buy;
        private System.Windows.Forms.Button button4BuyMedium;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}